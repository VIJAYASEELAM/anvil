## Task 2: Add user profile endpoint (variant)

Same goals as Task 1 but consider additional validation on email format in service implementation.