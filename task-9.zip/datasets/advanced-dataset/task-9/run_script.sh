#!/usr/bin/env bash
set -euo pipefail
pytest -q --maxfail=1
