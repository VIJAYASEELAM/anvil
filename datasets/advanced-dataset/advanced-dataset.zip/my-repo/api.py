"""API layer placeholders used by tasks.

Add handlers and route registration points here when implementing tasks.
"""

def register_routes(app):
    """Register routes on provided app object (web framework-agnostic).

    Expected to add functions like `GET /items`, `POST /items`, etc.
    """
    # TODO: implement route registration
    pass
