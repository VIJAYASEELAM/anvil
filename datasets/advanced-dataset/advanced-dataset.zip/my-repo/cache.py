"""Placeholder modules used by the task harnesses.

Leave implementations empty; participants will implement them as part of tasks.
"""

class Cache:
    """Simple cache API stub.

    Methods to implement:
    - get(key)
    - set(key, value, ttl=None)
    - invalidate(key)
    """

    def __init__(self):
        # TODO: implement
        pass

    def get(self, key):
        raise NotImplementedError

    def set(self, key, value, ttl: int | None = None):
        raise NotImplementedError

    def invalidate(self, key):
        raise NotImplementedError
