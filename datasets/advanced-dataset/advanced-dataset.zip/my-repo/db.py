"""Database access layer stubs.

Implement repository patterns and migrations as part of tasks.
"""

class UserRepository:
    def find_by_id(self, user_id: int):
        raise NotImplementedError

    def create_user(self, data: dict) -> int:
        raise NotImplementedError
