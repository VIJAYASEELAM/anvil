## Task 4: Add user profile endpoint (validation)

Implement `get_profile` and add `/api/profile`. Service should sanitize output (no internal fields).