## Task 6: Add user profile endpoint (robustness)

Add `get_profile` and protect route; ensure missing user returns 404.