## Task 9: Add user profile endpoint (compatibility)

Implement `get_profile` and `/api/profile`. Keep API shape stable for clients.