## Task 10: Add user profile endpoint (final)

Implement `get_profile` and `/api/profile` and ensure route uses `require_auth`.