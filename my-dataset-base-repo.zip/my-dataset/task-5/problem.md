## Task 5: Add user profile endpoint (integration)

Add `get_profile` and `/api/profile`. Ensure route uses `require_auth` and service returns dict.