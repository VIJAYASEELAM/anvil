## Task 8: Add user profile endpoint (formatting)

Implement `get_profile` and `/api/profile`; responses should be JSON-serializable.